<?php
$title="mijn tweede website";z
$naam"hasan";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?</title>
</head>
<body>
    
<h1>?php echo $title; ?</h1>
<p>Created by: <?php echo $naam;?</p>
</body>
</html>